import { useState } from "react";

function ProductCard({ product }) {
  const [count, setCount] = useState(0);

  return (
    <div style={{ border: "1px solid gray", margin: "10px", padding: "10px" }}>
      <h3>{product.name}</h3>
      <p>Price: ₹{product.price}</p>
      <button onClick={() => setCount(count + 1)}>
        Add to Cart ({count})
      </button>
    </div>
  );
}

export default ProductCard;
