import React, { useState } from "react";

function App() {
  const products = [
    { name: "Laptop", price: 60000 },
    { name: "Mobile", price: 30000 },
    { name: "Headphones", price: 2000 }
  ];

  // cart count for each product
  const [cartItems, setCartItems] = useState(
    products.map(() => 0)
  );

  const styles = {
    app: {
      minHeight: "100vh",
      background: "linear-gradient(135deg, #667eea, #764ba2)",
      padding: "40px",
      textAlign: "center",
      fontFamily: "Segoe UI, sans-serif"
    },
    heading: {
      marginBottom: "30px",
      color: "#fff"
    },
    productList: {
      display: "flex",
      justifyContent: "center",
      gap: "25px",
      flexWrap: "wrap"
    },
    card: {
      backgroundColor: "#fff",
      width: "280px",
      padding: "25px",
      borderRadius: "15px",
      boxShadow: "0 15px 30px rgba(0,0,0,0.2)",
      transition: "transform 0.3s"
    },
    title: {
      marginBottom: "10px",
      color: "#222"
    },
    price: {
      fontSize: "18px",
      color: "#555",
      marginBottom: "20px"
    },
    button: {
      backgroundColor: "#0d6efd",
      color: "#fff",
      border: "none",
      padding: "12px 18px",
      borderRadius: "8px",
      cursor: "pointer",
      fontSize: "15px"
    },
    cartInfo: {
      color: "#fff",
      fontSize: "18px",
      marginBottom: "20px"
    }
  };

  // total items in cart
  const totalItems = cartItems.reduce((a, b) => a + b, 0);

  const addToCart = index => {
    const updatedCart = [...cartItems];
    updatedCart[index] += 1;
    setCartItems(updatedCart);
  };

  return (
    <div style={styles.app}>
      <h1 style={styles.heading}>🛒 Online Shopping Website</h1>

      <div style={styles.cartInfo}>
        Items in Cart: <strong>{totalItems}</strong>
      </div>

      <div style={styles.productList}>
        {products.map((item, index) => (
          <div
            key={index}
            style={styles.card}
            onMouseEnter={e =>
              (e.currentTarget.style.transform = "translateY(-8px)")
            }
            onMouseLeave={e =>
              (e.currentTarget.style.transform = "translateY(0)")
            }
          >
            <h2 style={styles.title}>{item.name}</h2>
            <p style={styles.price}>₹{item.price}</p>

            <button
              style={styles.button}
              onClick={() => addToCart(index)}
            >
              Add to Cart ({cartItems[index]})
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
