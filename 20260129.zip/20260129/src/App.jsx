import React from "react";

function App() {
  const products = [
    { name: "Laptop", price: 60000 },
    { name: "Mobile", price: 30000 },
    { name: "Headphones", price: 2000 }
  ];

  const styles = {
    app: {
      minHeight: "100vh",
      backgroundColor: "#f4f6f8",
      padding: "40px",
      textAlign: "center",
      fontFamily: "Segoe UI, sans-serif"
    },
    heading: {
      marginBottom: "30px",
      color: "#333"
    },
    productList: {
      display: "flex",
      justifyContent: "center",
      gap: "25px",
      flexWrap: "wrap"
    },
    card: {
      backgroundColor: "#fff",
      width: "280px",
      padding: "25px",
      borderRadius: "15px",
      boxShadow: "0 10px 25px rgba(0,0,0,0.1)",
      transition: "transform 0.3s"
    },
    title: {
      marginBottom: "10px",
      color: "#222"
    },
    price: {
      fontSize: "18px",
      color: "#555",
      marginBottom: "20px"
    },
    button: {
      backgroundColor: "#0d6efd",
      color: "#fff",
      border: "none",
      padding: "12px 18px",
      borderRadius: "8px",
      cursor: "pointer",
      fontSize: "15px"
    }
  };

  return (
    <div style={styles.app}>
      <h1 style={styles.heading}>🛒 Online Shopping Website</h1>

      <div style={styles.productList}>
        {products.map((item, index) => (
          <div
            key={index}
            style={styles.card}
            onMouseEnter={e =>
              (e.currentTarget.style.transform = "translateY(-8px)")
            }
            onMouseLeave={e =>
              (e.currentTarget.style.transform = "translateY(0)")
            }
          >
            <h2 style={styles.title}>{item.name}</h2>
            <p style={styles.price}>₹{item.price}</p>
            <button style={styles.button}>Add to Cart (0)</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
