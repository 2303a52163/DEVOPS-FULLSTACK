COMMANDS TO RUN (VS CODE):

1. cd 20260129
2. npm install
3. npm run dev
Open browser: http://localhost:5173
