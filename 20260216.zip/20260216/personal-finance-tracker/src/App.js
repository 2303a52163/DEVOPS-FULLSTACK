import './App.css';

function App() {
  return (
    <div className="App">
      <h1>💰 Personal Finance Tracker</h1>

      <p>Track your income and expenses in one place.</p>

      <div className="card">
        <h2>Balance</h2>
        <p className="amount">$0.00</p>
      </div>

      <div className="card">
        <h2>Recent Transactions</h2>
        <p>No transactions yet.</p>
      </div>
    </div>
  );
}

export default App;
